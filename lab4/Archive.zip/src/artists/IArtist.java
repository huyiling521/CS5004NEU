package artists;

public interface IArtist {
    void receiveAward(String award);
    String [] getAwards();
}
